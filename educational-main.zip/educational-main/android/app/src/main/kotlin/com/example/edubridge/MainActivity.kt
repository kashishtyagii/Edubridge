package com.example.edubridge

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
